# Sailracingapp

This is a app to help during sailing races.

Features on the planning:

- Start timer
- Heading (compass)
- Speed over ground
- Wind direction
- Wind shifts
- Start line (time to line, ttk)
- Wind shift graphs
- Boat polars
- Wind predictions
- Boat effiency
- Map to plot courses
